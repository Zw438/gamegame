# Paddle Player

Android app that plays a shark-and-paddle game for you: it watches the screen, tracks the shark,
works out where it will land after each wall bounce, and drags the paddle there.

Built for a Samsung A17 with 3-button navigation (the nav bar is where the control panel sits).

## How it works

- **Screen capture** (MediaProjection) at 1/3 size. The shark is found as the grey/white blob, since the
  background is yellow, the rally number is olive, and the paddle is black.
- **Prediction**: keeps the last few positions, fits a velocity, notices bounces, folds in left/right/top
  walls, and predicts where the shark crosses the paddle's top edge. It re-aims every frame, so after the
  shark hits the paddle it immediately starts tracking the next landing spot.
- **Touch**: an accessibility service holds one finger down on the paddle and drags it.
- **Calibration**: finds the background colour, play area, header, paddle and shark size, then drags the
  paddle 150px and measures how far it moved (gives the finger-to-paddle gain). Walls and the top bounce
  position are also learned while it plays.

## Build

**GitHub Actions (no Android Studio needed):** push to `main`, open the Actions tab, run "Build APK", and
download `paddleplayer-debug-apk` from the run's Artifacts. Unzip it and install `app-debug.apk`.

**Android Studio:** open this folder and run the `app` configuration.

## Use

1. Install the APK. Open **Paddle Player**.
2. Tap *Open accessibility settings* and turn on Paddle Player (under Installed apps).
3. Tap *Start screen capture*. If Android asks what to share, choose the entire screen.
4. Open the game and wait for the countdown. Tap **Calibrate** on the panel at the bottom. The paddle will
   wiggle 150px and go back.
5. Tap **Start** (you can do this during the countdown). **Stop** lets go of the paddle. **X** hides the panel.

If the ball is lost for 3 seconds (game over), it stops by itself. Calibration only needs redoing if you
restart the capture.

## Tuning

Everything is in `Bot.kt` and `Predictor.kt`:

- `dur` in `PaddleAccessibilityService.pump()` caps how fast the finger moves.
- `maxN` in `Predictor` is how many samples the velocity fit uses (fewer = reacts faster, noisier).
- The `3` in `CaptureService` (`dm.widthPixels / 3`) is the capture downscale. Use 2 for sharper tracking
  if the phone keeps up.
