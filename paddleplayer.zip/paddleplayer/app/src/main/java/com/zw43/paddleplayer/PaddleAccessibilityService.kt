package com.zw43.paddleplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Sends the touches (one long drag that follows the paddle) and shows the small
 * control panel over the navigation bar. All touch state is handled on the main thread.
 */
class PaddleAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: PaddleAccessibilityService? = null
        private val main = Handler(Looper.getMainLooper())

        fun toast(msg: String) {
            main.post {
                val ctx = instance ?: return@post
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    private var panel: LinearLayout? = null
    private var holding = false
    private var busy = false
    private var stroke: GestureDescription.StrokeDescription? = null
    private var curX = 0f
    private var curY = 0f
    @Volatile private var desiredX = 0f

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        Bot.stop()
        hidePanel()
        instance = null
        return super.onUnbind(intent)
    }

    // ------------------------------------------------------------ control panel

    fun showPanel() {
        main.post {
            if (panel != null) return@post
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val dp = resources.displayMetrics.density
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(0xFF202020.toInt())
                setPadding((6 * dp).toInt(), 0, (6 * dp).toInt(), 0)
            }
            fun btn(label: String, onClick: () -> Unit) {
                val b = Button(this).apply {
                    text = label
                    textSize = 12f
                    isAllCaps = false
                    minWidth = 0
                    minimumWidth = 0
                    minHeight = 0
                    minimumHeight = 0
                    setPadding((10 * dp).toInt(), 0, (10 * dp).toInt(), 0)
                    setOnClickListener { onClick() }
                }
                row.addView(b, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, (38 * dp).toInt()
                ).apply { setMargins((3 * dp).toInt(), 0, (3 * dp).toInt(), 0) })
            }
            btn("Calibrate") { Bot.calibrate() }
            btn("Start") {
                val err = Bot.start()
                toast(err ?: "Playing. Tap Stop to let go.")
            }
            btn("Stop") { Bot.stop() }
            btn("X") { Bot.stop(); hidePanel() }

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                (48 * dp).toInt(),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            wm.addView(row, lp)
            panel = row
        }
    }

    fun hidePanel() {
        main.post {
            val p = panel ?: return@post
            panel = null
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(p)
            } catch (_: Exception) {
            }
        }
    }

    // ------------------------------------------------------------ touches

    /** Puts a finger down at (x, y) and keeps it there until endHold(). */
    fun beginHold(x: Float, y: Float) {
        desiredX = x
        main.post {
            curX = x
            curY = y
            stroke = null
            holding = true
            if (!busy) pump()
        }
    }

    /** Where the finger should be (screen px). Picked up by the running drag. */
    fun moveTo(x: Float) {
        desiredX = x.coerceIn(0f, resources.displayMetrics.widthPixels.toFloat())
    }

    fun endHold() {
        main.post {
            holding = false
            if (!busy) release()
        }
    }

    private fun pump() {
        if (!holding) {
            release()
            return
        }
        var tx = desiredX
        val dist = abs(tx - curX)
        val dur = (dist / 6f).toLong().coerceIn(16L, 100L)
        val path = Path()
        path.moveTo(curX, curY)
        if (dist >= 0.5f) path.lineTo(tx, curY) else tx = curX
        val s = try {
            stroke?.continueStroke(path, 0, dur, true)
                ?: GestureDescription.StrokeDescription(path, 0, dur, true)
        } catch (e: Exception) {
            fail("Touch error: ${e.message}")
            return
        }
        stroke = s
        busy = true
        val endX = tx
        val sent = dispatchGesture(
            GestureDescription.Builder().addStroke(s).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    curX = endX
                    busy = false
                    pump()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    busy = false
                    fail("Touch was interrupted. Stopped.")
                }
            },
            null
        )
        if (!sent) fail("Couldn't send touches. Is the accessibility service on?")
    }

    private fun fail(msg: String) {
        stroke = null
        busy = false
        holding = false
        Bot.stop()
        toast(msg)
    }

    /** Lifts the finger. */
    private fun release() {
        val s = stroke ?: return
        stroke = null
        val path = Path()
        path.moveTo(curX, curY)
        val fin = try {
            s.continueStroke(path, 0, 10, false)
        } catch (e: Exception) {
            return
        }
        busy = true
        val sent = dispatchGesture(
            GestureDescription.Builder().addStroke(fin).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    busy = false
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    busy = false
                }
            },
            null
        )
        if (!sent) busy = false
    }

    /** One finite drag used by calibration. Blocks (call from a worker thread). */
    fun dragTest(x: Float, y: Float, dx: Float): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        main.post {
            val path = Path()
            path.moveTo(x, y)
            path.lineTo(x + dx, y)
            val s = GestureDescription.StrokeDescription(path, 0, 350)
            val sent = dispatchGesture(
                GestureDescription.Builder().addStroke(s).build(),
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        ok = true
                        latch.countDown()
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        latch.countDown()
                    }
                },
                null
            )
            if (!sent) latch.countDown()
        }
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }
}
