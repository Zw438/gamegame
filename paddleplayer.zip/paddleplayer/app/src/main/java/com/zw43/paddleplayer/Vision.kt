package com.zw43.paddleplayer

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** One downscaled screen capture. rgb holds 0xRRGGBB per pixel. */
class Frame(val w: Int, val h: Int, val rgb: IntArray, val timeMs: Long)

/** Everything measured during calibration, in frame (downscaled) coordinates. */
class Calib {
    var bgR = 255
    var bgG = 243
    var bgB = 153
    var playTop = 0
    var playBottom = 0
    var playLeft = 0
    var playRight = 0
    var headerBottom = 0
    var paddleX = 0f      // paddle centre x
    var paddleY = 0f      // paddle centre y
    var paddleHalfW = 0f
    var paddleHalfH = 0f
    var gain = 1f         // paddle movement per finger movement (1 = paddle follows finger exactly)
    var ballR = 14f
}

class BallObs(val x: Float, val y: Float, val r: Float)

object Vision {
    private fun red(p: Int) = (p shr 16) and 255
    private fun green(p: Int) = (p shr 8) and 255
    private fun blue(p: Int) = p and 255

    private fun bin(p: Int): Int =
        (((p shr 19) and 31) shl 10) or (((p shr 11) and 31) shl 5) or ((p shr 3) and 31)

    private fun isBg(p: Int, c: Calib): Boolean =
        abs(red(p) - c.bgR) + abs(green(p) - c.bgG) + abs(blue(p) - c.bgB) < 45

    private fun isBlack(p: Int): Boolean = red(p) < 45 && green(p) < 45 && blue(p) < 45

    /**
     * Finds the background colour, the play area, the header (avatars/scores) and the paddle
     * in a single frame. Throws IllegalStateException with a readable message on failure.
     */
    fun calibrateStatic(f: Frame): Calib {
        val w = f.w
        val h = f.h
        val px = f.rgb
        val c = Calib()

        // 1. background = most common coarse colour
        val counts = IntArray(32 * 32 * 32)
        for (p in px) counts[bin(p)]++
        var best = 0
        for (i in counts.indices) if (counts[i] > counts[best]) best = i
        var sr = 0L
        var sg = 0L
        var sb = 0L
        var n = 0L
        for (p in px) {
            if (bin(p) == best) {
                sr += red(p); sg += green(p); sb += blue(p); n++
            }
        }
        check(n > w * h / 10) { "couldn't find the game's background colour" }
        c.bgR = (sr / n).toInt(); c.bgG = (sg / n).toInt(); c.bgB = (sb / n).toInt()

        // 2. play area: rows/cols that are mostly background
        var top = -1
        var bottom = -1
        for (y in 0 until h) {
            var cnt = 0
            val base = y * w
            for (x in 0 until w) if (isBg(px[base + x], c)) cnt++
            if (cnt > w * 0.4) {
                if (top < 0) top = y
                bottom = y
            }
        }
        check(top >= 0) { "couldn't find the play area" }
        c.playTop = top
        c.playBottom = bottom

        var left = -1
        var right = -1
        for (x in 0 until w) {
            var cnt = 0
            var rows = 0
            var y = top
            while (y <= bottom) {
                if (isBg(px[y * w + x], c)) cnt++
                rows++
                y += 2
            }
            if (cnt > rows * 0.4) {
                if (left < 0) left = x
                right = x
            }
        }
        check(left >= 0) { "couldn't find the play area" }
        c.playLeft = left
        c.playRight = right

        // 3. header: last row in the top quarter of the play area that has non-background stuff
        var header = top
        val headerScanEnd = top + (bottom - top) / 4
        for (y in top..headerScanEnd) {
            var cnt = 0
            for (x in left..right) {
                val p = px[y * w + x]
                val d = abs(red(p) - c.bgR) + abs(green(p) - c.bgG) + abs(blue(p) - c.bgB)
                if (d >= 60) cnt++
            }
            if (cnt >= 3) header = y
        }
        c.headerBottom = min(header + 3, headerScanEnd)

        // 4. paddle: black blob in the lower part of the play area
        val yFrom = bottom - ((bottom - top) * 0.35f).toInt()
        val box = findPaddle(f, c, yFrom, bottom)
            ?: error("couldn't find the paddle (is the game on screen with the paddle visible?)")
        c.paddleX = (box[0] + box[2]) / 2f
        c.paddleY = (box[1] + box[3]) / 2f
        c.paddleHalfW = (box[2] - box[0] + 1) / 2f
        c.paddleHalfH = (box[3] - box[1] + 1) / 2f
        return c
    }

    /** Returns [x0, y0, x1, y1] of the biggest black wide blob between yFrom..yTo, or null. */
    fun findPaddle(f: Frame, c: Calib, yFrom: Int, yTo: Int): IntArray? {
        val w = f.w
        val px = f.rgb
        val y0 = max(yFrom, 0)
        val y1 = min(yTo, f.h - 1)
        if (y1 < y0) return null
        val minRow = max(6, (c.playRight - c.playLeft) / 12)

        // rows that contain a long run of black
        val rowOk = BooleanArray(y1 - y0 + 1)
        for (y in y0..y1) {
            var n = 0
            for (x in c.playLeft..c.playRight) if (isBlack(px[y * w + x])) n++
            rowOk[y - y0] = n >= minRow
        }
        var bestS = -1
        var bestLen = 0
        var s = -1
        for (i in rowOk.indices) {
            if (rowOk[i]) {
                if (s < 0) s = i
                val len = i - s + 1
                if (len > bestLen) { bestLen = len; bestS = s }
            } else s = -1
        }
        if (bestS < 0 || bestLen < 4) return null
        val ry0 = y0 + bestS
        val ry1 = ry0 + bestLen - 1

        // columns inside those rows
        val need = max(2, bestLen / 3)
        var cs = -1
        var cBestS = -1
        var cBestLen = 0
        for (x in c.playLeft..c.playRight) {
            var n = 0
            for (y in ry0..ry1) if (isBlack(px[y * w + x])) n++
            if (n >= need) {
                if (cs < 0) cs = x
                val len = x - cs + 1
                if (len > cBestLen) { cBestLen = len; cBestS = cs }
            } else cs = -1
        }
        if (cBestS < 0 || cBestLen < minRow) return null
        return intArrayOf(cBestS, ry0, cBestS + cBestLen - 1, ry1)
    }

    /** Re-measures the paddle near its calibrated row. Returns centre x or null. */
    fun paddleCentreX(f: Frame, c: Calib): Float? {
        val yFrom = (c.paddleY - c.paddleHalfH - 3).toInt()
        val yTo = min((c.paddleY + c.paddleHalfH + 3).toInt(), c.playBottom)
        val box = findPaddle(f, c, yFrom, yTo) ?: return null
        return (box[0] + box[2]) / 2f
    }

    /**
     * Finds the shark: grey/white pixels (low colour saturation) that are neither the yellow
     * background, the olive rally number, nor the black paddle. Search is limited to the box.
     */
    fun findBall(f: Frame, x0: Int, y0: Int, x1: Int, y1: Int): BallObs? {
        val w = f.w
        val px = f.rgb
        val xa = max(x0, 0)
        val xb = min(x1, f.w - 1)
        val ya = max(y0, 0)
        val yb = min(y1, f.h - 1)
        var sx = 0L
        var sy = 0L
        var cnt = 0
        var minX = Int.MAX_VALUE
        var maxX = -1
        var minY = Int.MAX_VALUE
        var maxY = -1
        for (y in ya..yb) {
            val base = y * w
            for (x in xa..xb) {
                val p = px[base + x]
                val r = red(p)
                val g = green(p)
                val b = blue(p)
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                if (mx >= 90 && (mx - mn) * 100 <= 22 * mx) {
                    sx += x; sy += y; cnt++
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (cnt < 25) return null
        val radius = max(maxX - minX, maxY - minY) / 2f
        return BallObs(sx.toFloat() / cnt, sy.toFloat() / cnt, radius)
    }
}
