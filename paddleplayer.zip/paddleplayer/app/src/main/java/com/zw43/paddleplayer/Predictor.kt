package com.zw43.paddleplayer

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/** A direction change seen by the tracker: the last sample before it and the first ones after. */
class Bounce(
    val x1: Double, val y1: Double, val t1: Double, val vx1: Double, val vy1: Double,
    val x2: Double, val y2: Double, val t2: Double, val vx2: Double, val vy2: Double
)

class Landing(val x: Double, val timeSec: Double)

/**
 * Keeps the last few ball positions, estimates velocity, notices bounces (a sample that
 * doesn't fit the current straight line) and predicts where the ball will cross the paddle
 * line, folding in left/right/top wall bounces. All numbers are frame pixels and seconds.
 */
class Predictor {
    private val maxN = 5
    private val ts = DoubleArray(maxN)
    private val xs = DoubleArray(maxN)
    private val ys = DoubleArray(maxN)
    private var n = 0
    private var pre: DoubleArray? = null // x, y, t, vx, vy just before a bounce

    var vx = 0.0
        private set
    var vy = 0.0
        private set
    var hasVel = false
        private set
    var lastX = 0.0
        private set
    var lastY = 0.0
        private set
    var lastT = 0.0
        private set

    fun clear() {
        n = 0
        hasVel = false
        pre = null
    }

    /** Adds a sample. Returns a Bounce once a direction change has two post-bounce samples. */
    fun add(t: Double, x: Double, y: Double, devLimit: Double): Bounce? {
        if (n >= 3 && hasVel) {
            val dt = t - lastT
            val dx = x - (lastX + vx * dt)
            val dy = y - (lastY + vy * dt)
            if (hypot(dx, dy) > devLimit) {
                pre = doubleArrayOf(lastX, lastY, lastT, vx, vy)
                n = 0
                hasVel = false
            }
        }
        if (n == maxN) {
            for (i in 1 until maxN) {
                ts[i - 1] = ts[i]; xs[i - 1] = xs[i]; ys[i - 1] = ys[i]
            }
            n--
        }
        ts[n] = t; xs[n] = x; ys[n] = y
        n++
        lastX = x; lastY = y; lastT = t
        if (n >= 2) fitVelocity()

        var result: Bounce? = null
        val p = pre
        if (n == 2 && p != null && hasVel) {
            if (ts[0] - p[2] < 0.15) {
                result = Bounce(p[0], p[1], p[2], p[3], p[4], xs[0], ys[0], ts[0], vx, vy)
            }
            pre = null
        }
        return result
    }

    private fun fitVelocity() {
        var tm = 0.0
        var xm = 0.0
        var ym = 0.0
        for (i in 0 until n) { tm += ts[i]; xm += xs[i]; ym += ys[i] }
        tm /= n; xm /= n; ym /= n
        var den = 0.0
        var nx = 0.0
        var ny = 0.0
        for (i in 0 until n) {
            val dt = ts[i] - tm
            den += dt * dt
            nx += dt * (xs[i] - xm)
            ny += dt * (ys[i] - ym)
        }
        if (den < 1e-9) return
        vx = nx / den
        vy = ny / den
        hasVel = true
    }

    /**
     * Where (x) and when the ball will be at y = yLand, moving down. Returns null if the ball
     * isn't moving vertically enough to say.
     */
    fun landing(yLand: Double, left: Double, right: Double, top: Double): Landing? {
        if (!hasVel) return null
        var yy = lastY
        var vyy = vy
        var tt = 0.0
        if (vyy < 0) {
            tt += max(0.0, (yy - top) / -vyy)
            yy = top
            vyy = -vyy
        }
        if (abs(vyy) < 20.0) return null
        tt += (yLand - yy) / vyy
        if (tt < 0) tt = 0.0
        return Landing(reflect(lastX + vx * tt, left, right), tt)
    }

    companion object {
        /** Folds x into [lo, hi] as if bouncing between two walls. */
        fun reflect(x: Double, lo: Double, hi: Double): Double {
            val len = hi - lo
            if (len <= 0) return lo
            var u = (x - lo) % (2 * len)
            if (u < 0) u += 2 * len
            if (u > len) u = 2 * len - u
            return lo + u
        }

        /**
         * Given the straight-line motion before and after a bounce, returns the coordinate
         * of the wall for one axis: pre-line pos1 + v1*(t - t1), post-line pos2 + v2*(t - t2).
         */
        fun wallFromBounce(pos1: Double, t1: Double, v1: Double, pos2: Double, t2: Double, v2: Double): Double? {
            val den = v1 - v2
            if (abs(den) < 1e-6) return null
            val tb = (pos2 - pos1 + v1 * t1 - v2 * t2) / den
            return pos1 + v1 * (tb - t1)
        }
    }
}
