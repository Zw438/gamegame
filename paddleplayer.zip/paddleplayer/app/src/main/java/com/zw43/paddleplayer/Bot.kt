package com.zw43.paddleplayer

import android.util.Log
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Glue between the screen capture (frames in), the vision/prediction code, and the
 * accessibility service (touches out). Coordinates: "frame" = downscaled capture pixels,
 * "screen" = real display pixels (frame * sx / sy).
 */
object Bot {
    private const val TAG = "PaddlePlayer"

    @Volatile var latest: Frame? = null
    @Volatile var calib: Calib? = null
    @Volatile var running = false
    @Volatile var sx = 3f
    @Volatile var sy = 3f

    private val predictor = Predictor()

    // touch-down reference: paddle centre (frame px) and finger x (screen px)
    private var p0 = 0f
    private var f0 = 0f

    // wall estimates for the ball centre (frame px); learned from observed bounces
    private var leftWall = 0.0
    private var rightWall = 0.0
    private var topWall = 0.0

    private var lastTarget = -1f
    private var lastSeenMs = 0L
    private var lastSeenSec = 0.0
    private var lastBX = 0f
    private var lastBY = 0f
    private var hiddenSince = -1.0
    private var hiddenLastY = 0.0
    private var hiddenVy = 0.0
    private var calibrating = false

    fun status(msg: String) {
        Log.i(TAG, msg)
        PaddleAccessibilityService.toast(msg)
    }

    // ---------------------------------------------------------------- frames

    fun onFrame(f: Frame) {
        latest = f
        if (!running) return
        val c = calib ?: return
        try {
            step(f, c)
        } catch (e: Exception) {
            Log.e(TAG, "step failed", e)
        }
    }

    private fun step(f: Frame, c: Calib) {
        val r = c.ballR
        val yTop = c.headerBottom + 1
        val yBot = (c.paddleY - c.paddleHalfH).toInt() - 1
        val t = f.timeMs / 1000.0

        // look near where the ball was first, then fall back to the whole play area
        var obs: BallObs? = null
        if (predictor.hasVel && f.timeMs - lastSeenMs < 200) {
            val m = (r * 4 + 40).toInt()
            obs = Vision.findBall(
                f, (lastBX - m).toInt(), max(yTop, (lastBY - m).toInt()),
                (lastBX + m).toInt(), min(yBot, (lastBY + m).toInt())
            )
        }
        if (obs == null) obs = Vision.findBall(f, c.playLeft, yTop, c.playRight, yBot)

        if (obs != null) {
            // ball came back after disappearing behind the header: learn where the top wall is
            if (hiddenSince >= 0) {
                val th = t - hiddenSince
                if (th in 0.05..1.5 && hiddenVy < 0) {
                    val est = (hiddenLastY + obs.y - abs(hiddenVy) * th) / 2.0
                    val clamped = est.coerceIn(c.playTop.toDouble(), c.headerBottom + 1.0)
                    topWall = 0.5 * topWall + 0.5 * clamped
                }
                hiddenSince = -1.0
                predictor.clear()
            }
            lastSeenMs = f.timeMs
            lastSeenSec = t
            lastBX = obs.x
            lastBY = obs.y
            if (obs.r in 6f..60f) c.ballR = 0.9f * c.ballR + 0.1f * obs.r

            val b = predictor.add(t, obs.x.toDouble(), obs.y.toDouble(), max(6.0, 0.6 * c.ballR))
            if (b != null) learnWalls(b, c)
        } else {
            val gone = f.timeMs - lastSeenMs
            if (hiddenSince < 0 && lastSeenMs > 0 && predictor.hasVel && predictor.vy < 0 &&
                lastBY < c.headerBottom + 4 * r + 10
            ) {
                hiddenSince = lastSeenSec
                hiddenLastY = lastBY.toDouble()
                hiddenVy = predictor.vy
            }
            if (gone > 1500 && hiddenSince < 0) predictor.clear()
            if (gone > 3000) {
                status("Lost the ball for 3 seconds. Stopped.")
                stop()
                return
            }
        }

        val yLand = (c.paddleY - c.paddleHalfH - c.ballR).toDouble()
        val l = predictor.landing(yLand, leftWall, rightWall, topWall)
        if (l != null) moveTo(l.x.toFloat(), c)
    }

    private fun learnWalls(b: Bounce, c: Calib) {
        if (b.vx1 * b.vx2 < 0 && abs(b.vx1) > 40 && abs(b.vx2) > 40) {
            val xw = Predictor.wallFromBounce(b.x1, b.t1, b.vx1, b.x2, b.t2, b.vx2)
            if (xw != null && xw > c.playLeft - 6 && xw < c.playRight + 6) {
                val mid = (c.playLeft + c.playRight) / 2.0
                if (b.vx1 < 0 && xw < mid) leftWall = 0.5 * leftWall + 0.5 * xw
                if (b.vx1 > 0 && xw > mid) rightWall = 0.5 * rightWall + 0.5 * xw
            }
        }
        if (b.vy1 < 0 && b.vy2 > 40 && abs(b.vy1) > 40) {
            val yw = Predictor.wallFromBounce(b.y1, b.t1, b.vy1, b.y2, b.t2, b.vy2)
            if (yw != null && yw > c.playTop - 6 && yw < c.headerBottom + 100) {
                topWall = 0.5 * topWall + 0.5 * yw
            }
        }
    }

    private fun moveTo(targetFrame: Float, c: Calib) {
        val tgt = targetFrame.coerceIn(c.playLeft + c.paddleHalfW, c.playRight - c.paddleHalfW)
        if (abs(tgt - lastTarget) < 3f) return
        lastTarget = tgt
        val fingerX = f0 + (tgt - p0) * sx / c.gain
        PaddleAccessibilityService.instance?.moveTo(fingerX)
    }

    private fun initWalls(c: Calib) {
        leftWall = c.playLeft + c.ballR.toDouble()
        rightWall = c.playRight - c.ballR.toDouble()
        topWall = c.playTop + c.ballR.toDouble()
    }

    private fun resetTracking() {
        predictor.clear()
        lastTarget = -1f
        lastSeenMs = 0L
        hiddenSince = -1.0
    }

    // ---------------------------------------------------------------- controls

    /** Returns an error message, or null when the bot is running. */
    fun start(): String? {
        if (running) return "Already running"
        if (calibrating) return "Calibration is still running"
        val c = calib ?: return "Calibrate first"
        val f = latest ?: return "No frames yet. Start screen capture in the app."
        val svc = PaddleAccessibilityService.instance ?: return "Accessibility service isn't running"
        val pcx = Vision.paddleCentreX(f, c) ?: return "Can't see the paddle. Is the game on screen?"
        p0 = pcx
        f0 = pcx * sx
        resetTracking()
        lastTarget = pcx
        lastSeenMs = f.timeMs
        svc.beginHold(f0, c.paddleY * sy)
        running = true
        return null
    }

    fun stop() {
        val was = running
        running = false
        if (was) PaddleAccessibilityService.instance?.endHold()
    }

    /** Measures the screen, then drags the paddle a little to learn how it follows the finger. */
    fun calibrate() {
        if (running) stop()
        if (calibrating) return
        calibrating = true
        thread(name = "calibrate") {
            try {
                val svc = PaddleAccessibilityService.instance
                    ?: error("accessibility service isn't running")
                val f0f = latest ?: error("no frames yet. Start screen capture in the app")
                val c = Vision.calibrateStatic(f0f)

                // ball size, if the shark is visible right now
                val ball = Vision.findBall(
                    f0f, c.playLeft, c.headerBottom + 1, c.playRight,
                    (c.paddleY - c.paddleHalfH).toInt() - 1
                )
                c.ballR = if (ball != null && ball.r in 6f..60f) ball.r
                else (c.playRight - c.playLeft) * 0.045f

                // drag test: move toward whichever side has more room
                val goRight = c.paddleX < (c.playLeft + c.playRight) / 2f
                val dScreen = if (goRight) 150f else -150f
                val startX = c.paddleX * sx
                val y = c.paddleY * sy
                if (!svc.dragTest(startX, y, dScreen)) error("the test drag was blocked or cancelled")
                Thread.sleep(500)
                val f1 = latest ?: error("lost the capture")
                val p1 = Vision.paddleCentreX(f1, c) ?: error("lost sight of the paddle after the test drag")
                val movedScreen = (p1 - c.paddleX) * sx
                if (abs(movedScreen) < 8f) {
                    error("the paddle didn't move when I dragged it. Is the game running (countdown is fine)?")
                }
                c.gain = (movedScreen / dScreen).coerceIn(0.2f, 3f)

                // put the paddle back
                svc.dragTest(p1 * sx, y, -movedScreen / c.gain)
                Thread.sleep(300)

                initWalls(c)
                calib = c
                status(
                    "Calibrated. Paddle follows finger at %.2fx, paddle width %d px, ball %s."
                        .format(c.gain, (c.paddleHalfW * 2 * sx).toInt(), if (ball != null) "found" else "not visible (guessing size)")
                )
            } catch (e: Exception) {
                Log.e(TAG, "calibration failed", e)
                status("Calibration failed: ${e.message}")
            } finally {
                calibrating = false
            }
        }
    }
}
