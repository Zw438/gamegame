package com.zw43.paddleplayer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val reqCapture = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (40 * dp).toInt(), (20 * dp).toInt(), (20 * dp).toInt())
        }
        fun label(s: String, size: Float = 15f) {
            col.addView(TextView(this).apply {
                text = s
                textSize = size
                setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
            })
        }
        fun button(s: String, onClick: () -> Unit) {
            col.addView(Button(this).apply {
                text = s
                isAllCaps = false
                setOnClickListener { onClick() }
            })
        }

        label("Paddle Player", 26f)
        label("1. Turn on Paddle Player in Accessibility settings (look under Installed apps). It sends the touches that move the paddle.")
        button("Open accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        label("2. Start screen capture so the app can see the game. If Android asks what to share, pick the entire screen.")
        button("Start screen capture") {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
        }
        label("3. Open the game while the countdown is showing. Tap Calibrate on the panel at the bottom of the screen, then Start. Stop lets go of the paddle.")
        button("Stop everything") {
            Bot.stop()
            stopService(Intent(this, CaptureService::class.java))
        }
        setContentView(ScrollView(this).apply { addView(col) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
        }
    }
}
