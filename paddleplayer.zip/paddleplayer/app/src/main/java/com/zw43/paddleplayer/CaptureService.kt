package com.zw43.paddleplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.widget.Toast
import java.nio.ByteOrder

/** Foreground service that mirrors the screen into a small (1/3 size) ImageReader. */
class CaptureService : Service() {

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startCapture(code, data)
        } catch (e: Exception) {
            toast("Couldn't start screen capture: ${e.message}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("capture", "Screen capture", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "capture")
            .setContentTitle("Paddle Player")
            .setContentText("Screen capture is running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj

        val ht = HandlerThread("capture")
        ht.start()
        thread = ht
        val handler = Handler(ht.looper)

        // must be registered before createVirtualDisplay on Android 14+
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopping) stopSelf()
            }
        }, handler)

        val dm = DisplayMetrics()
        getSystemService(DisplayManager::class.java)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val cw = dm.widthPixels / 3
        val ch = dm.heightPixels / 3
        Bot.sx = dm.widthPixels.toFloat() / cw
        Bot.sy = dm.heightPixels.toFloat() / ch

        val rd = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        reader = rd
        rd.setOnImageAvailableListener({ r -> onImage(r, cw, ch) }, handler)
        display = proj.createVirtualDisplay(
            "paddleplayer", cw, ch, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, handler
        )

        val svc = PaddleAccessibilityService.instance
        if (svc == null) {
            toast("Capture is running, but turn on the Paddle Player accessibility service to see the control panel.")
        } else {
            svc.showPanel()
            toast("Capture started. Open the game, then use the panel at the bottom.")
        }
    }

    private fun onImage(r: ImageReader, cw: Int, ch: Int) {
        val img = r.acquireLatestImage() ?: return
        try {
            val plane = img.planes[0]
            val buf = plane.buffer.order(ByteOrder.nativeOrder()).asIntBuffer()
            val stride = plane.rowStride / 4
            val out = IntArray(cw * ch)
            for (y in 0 until ch) {
                val bo = y * stride
                val oo = y * cw
                for (x in 0 until cw) {
                    val v = buf.get(bo + x) // little-endian int of bytes R,G,B,A
                    out[oo + x] = ((v and 255) shl 16) or (v and 0xFF00) or ((v shr 16) and 255)
                }
            }
            Bot.onFrame(Frame(cw, ch, out, img.timestamp / 1_000_000L))
        } finally {
            img.close()
        }
    }

    private fun toast(msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        stopping = true
        Bot.stop()
        PaddleAccessibilityService.instance?.hidePanel()
        display?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
}
